export enum AppStage {
  LANDING = 0,
  STANZA_1 = 1,
  STANZA_2 = 2,
  STANZA_3 = 3,
  STANZA_4 = 4,
  CONCLUSION = 5
}

export interface NavProps {
  currentStage: AppStage;
  setStage: (stage: AppStage) => void;
}

export interface ScreenProps {
  onNext: () => void;
  isActive: boolean;
}