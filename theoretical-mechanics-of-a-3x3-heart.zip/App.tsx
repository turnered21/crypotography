import React, { useState, useEffect } from 'react';
import { AppStage } from './types';
import { Navigation } from './components/Navigation';
import { Landing } from './components/Landing';
import { StanzaOne } from './components/StanzaOne';
import { StanzaTwo } from './components/StanzaTwo';
import { StanzaThree } from './components/StanzaThree';
import { StanzaFour } from './components/StanzaFour';
import { FinalRevelation } from './components/FinalRevelation';

const App: React.FC = () => {
  const [stage, setStage] = useState<AppStage>(AppStage.LANDING);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Smooth transition handler
  const handleStageChange = (newStage: AppStage) => {
    setIsTransitioning(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      setStage(newStage);
      setIsTransitioning(false);
    }, 300);
  };

  const nextStage = () => {
    if (stage < AppStage.CONCLUSION) {
      handleStageChange(stage + 1);
    } else {
      handleStageChange(AppStage.LANDING);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [stage]);

  return (
    <div className="min-h-screen bg-dark">
      <Navigation currentStage={stage} setStage={handleStageChange} />
      
      <div className={`transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
        {stage === AppStage.LANDING && <Landing onNext={nextStage} isActive={stage === AppStage.LANDING} />}
        {stage === AppStage.STANZA_1 && <StanzaOne onNext={nextStage} isActive={stage === AppStage.STANZA_1} />}
        {stage === AppStage.STANZA_2 && <StanzaTwo onNext={nextStage} isActive={stage === AppStage.STANZA_2} />}
        {stage === AppStage.STANZA_3 && <StanzaThree onNext={nextStage} isActive={stage === AppStage.STANZA_3} />}
        {stage === AppStage.STANZA_4 && <StanzaFour onNext={nextStage} isActive={stage === AppStage.STANZA_4} />}
        {stage === AppStage.CONCLUSION && <FinalRevelation onNext={nextStage} isActive={stage === AppStage.CONCLUSION} />}
      </div>
    </div>
  );
};

export default App;